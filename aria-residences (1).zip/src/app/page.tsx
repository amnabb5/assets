'use client';

/**
 * Page — the single user-visible route ("/").
 *
 * Acts as the high-level state machine:
 *   LANDING        → <Landing /> (marketing page)
 *   CITY_ORBIT     → <CityExperience /> (3D orbit + selector)
 *   ZOOM_TRANSITION→ <CityExperience /> (same canvas, GSAP camera tween)
 *   WALKTHROUGH    → <WalkthroughScene /> (first-person interior)
 *
 * The 3D experiences are dynamically imported with ssr:false to keep three.js
 * off the server-render path (avoids SSR/hydration issues with WebGL).
 */
import dynamic from 'next/dynamic';
import { useAppStore } from '@/state/useAppStore';
import Landing from '@/components/Landing/Landing';

const CityExperience = dynamic(
  () => import('@/components/CityScene/CityExperience'),
  { ssr: false }
);
const WalkthroughScene = dynamic(
  () => import('@/components/Walkthrough/WalkthroughScene'),
  { ssr: false }
);

export default function Home() {
  const stage = useAppStore((s) => s.stage);

  if (stage === 'CITY_ORBIT' || stage === 'ZOOM_TRANSITION') {
    return <CityExperience />;
  }
  if (stage === 'WALKTHROUGH') {
    return <WalkthroughScene />;
  }
  return <Landing />;
}
