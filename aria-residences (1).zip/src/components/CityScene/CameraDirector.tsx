'use client';
/* eslint-disable react-hooks/immutability -- R3F's camera/gl are mutated
   imperatively by design (the intended API for useThree values). The
   react-hooks/immutability rule flags this as a false positive. */

/**
 * CameraDirector — owns camera behavior across CITY_ORBIT and ZOOM_TRANSITION.
 *
 *  CITY_ORBIT:
 *    OrbitControls (drei) is rendered with autoRotate, giving a slow cinematic
 *    orbit. The user can also drag to look around. We render OrbitControls ONLY
 *    in this stage so it never fights the zoom tween.
 *
 *  ZOOM_TRANSITION:
 *    OrbitControls unmounts. A GSAP timeline tweens:
 *      - camera.position  → just outside the selected floor's facade
 *      - a lookAt target  → the facade point at the selected floor's height
 *      - camera.fov       → a gentle dolly-in (then updateProjectionMatrix)
 *    A useFrame loop applies camera.lookAt(target) every frame so orientation
 *    tracks the tweened target. On complete → setStage('WALKTHROUGH').
 *
 *  TWEAK POINTS (for real models with different scale/origin):
 *    - The end camera position uses BUILDING_CONFIG.facadeTarget + floorWorldY().
 *      Edit those in src/config/apartments.ts to retarget the zoom.
 *    - ORBIT_RADIUS / ORBIT_HEIGHT / ORBIT_TARGET below tune the orbit framing.
 *    - ZOOM_DURATION / ZOOM_FOV_END tune the transition feel.
 */
import { useEffect, useRef } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import { OrbitControls } from '@react-three/drei';
import type { OrbitControls as OrbitControlsImpl } from 'three-stdlib';
import gsap from 'gsap';
import * as THREE from 'three';
import { useAppStore } from '@/state/useAppStore';
import { BUILDING_CONFIG, floorWorldY } from '@/config/apartments';

// Orbit framing constants (tweak to reframe the building).
const ORBIT_RADIUS = 18;
const ORBIT_HEIGHT = 9;
const ORBIT_TARGET: [number, number, number] = [0, 8, 0];
const ORBIT_AUTOROTATE_SPEED = 0.6; // drei units

// Zoom transition constants (tweak the "enter apartment" feel).
const ZOOM_DURATION = 2.4;
const ZOOM_FOV_END = 32;
// How far outside the facade the camera ends (world units).
const FACADE_OFFSET = 1.4;

export function CameraDirector() {
  const { camera } = useThree();
  const stage = useAppStore((s) => s.stage);
  const selectedFloor = useAppStore((s) => s.selectedFloor);
  const setStage = useAppStore((s) => s.setStage);

  const controlsRef = useRef<OrbitControlsImpl | null>(null);
  const lookTarget = useRef(new THREE.Vector3(...ORBIT_TARGET));
  const tweenRef = useRef<gsap.core.Timeline | null>(null);

  // Initialise camera on mount.
  useEffect(() => {
    const cam = camera as THREE.PerspectiveCamera;
    cam.fov = 50;
    cam.near = 0.1;
    cam.far = 200;
    cam.position.set(0, ORBIT_HEIGHT, ORBIT_RADIUS);
    cam.updateProjectionMatrix();
    cam.lookAt(...ORBIT_TARGET);
  }, [camera]);

  // Kick off the zoom tween when entering ZOOM_TRANSITION.
  useEffect(() => {
    if (stage !== 'ZOOM_TRANSITION' || !selectedFloor) return;

    const cam = camera as THREE.PerspectiveCamera;
    const floorY = floorWorldY(selectedFloor);
    const facadeZ = BUILDING_CONFIG.facadeTarget[2]; // +Z facade
    const endPos = {
      x: BUILDING_CONFIG.facadeTarget[0],
      y: floorY,
      z: facadeZ + FACADE_OFFSET,
    };
    const endTarget = {
      x: BUILDING_CONFIG.facadeTarget[0],
      y: floorY,
      z: facadeZ - 0.5, // look just through the facade, into the floor
    };

    // Start the lookTarget from the current orbit target so the orientation
    // tween begins smoothly from where the user was looking.
    lookTarget.current.set(...ORBIT_TARGET);

    const tl = gsap.timeline({
      defaults: { duration: ZOOM_DURATION, ease: 'power2.inOut' },
      onComplete: () => setStage('WALKTHROUGH'),
    });

    tl.to(cam.position, endPos, 0);
    tl.to(lookTarget.current, endTarget, 0);
    tl.to(
      cam,
      { fov: ZOOM_FOV_END, onUpdate: () => cam.updateProjectionMatrix() },
      0
    );

    tweenRef.current = tl;

    return () => {
      tl.kill();
      tweenRef.current = null;
    };
  }, [stage, selectedFloor, camera, setStage]);

  // Per-frame: during ZOOM_TRANSITION, keep the camera looking at the tweened
  // target. (During CITY_ORBIT, OrbitControls handles orientation itself.)
  useFrame(() => {
    if (stage === 'ZOOM_TRANSITION') {
      camera.lookAt(lookTarget.current);
    }
  });

  return (
    <>
      {stage === 'CITY_ORBIT' && (
        <OrbitControls
          ref={controlsRef}
          target={ORBIT_TARGET}
          enablePan={false}
          autoRotate
          autoRotateSpeed={ORBIT_AUTOROTATE_SPEED}
          minDistance={10}
          maxDistance={32}
          minPolarAngle={Math.PI * 0.18}
          maxPolarAngle={Math.PI * 0.52}
          enableDamping
          dampingFactor={0.08}
        />
      )}
    </>
  );
}
