'use client';

/**
 * CityExperience — full-screen 3D canvas for the CITY_ORBIT + ZOOM_TRANSITION
 * stages, with the HTML selector and transition overlays layered on top.
 *
 * Mounted whenever stage is CITY_ORBIT or ZOOM_TRANSITION (see page.tsx). When
 * the zoom tween completes, CameraDirector flips the stage to WALKTHROUGH and
 * this whole component unmounts in favor of <WalkthroughScene />.
 *
 * The Canvas uses Suspense + the shared <LoadingOverlay /> so both placeholder
 * and real-GLB loading show a progress bar.
 */
import { Suspense } from 'react';
import { Canvas } from '@react-three/fiber';
import { AnimatePresence } from 'framer-motion';
import * as THREE from 'three';
import { useAppStore } from '@/state/useAppStore';
import { CameraDirector } from './CameraDirector';
import { FloorUnitSelector } from './FloorUnitSelector';
import { MainBuildingModel } from '@/components/three/MainBuildingModel';
import { CitySurroundings } from './PlaceholderBuilding';
import { TransitionOverlay } from '@/components/Transition/TransitionOverlay';
import { LoadingOverlay } from '@/components/three/LoadingOverlay';

export default function CityExperience() {
  const stage = useAppStore((s) => s.stage);

  return (
    <div className="fixed inset-0 z-40 bg-background">
      <Canvas
        shadows
        dpr={[1, 2]}
        gl={{ antialias: true, toneMapping: THREE.ACESFilmicToneMapping }}
        camera={{ fov: 50, near: 0.1, far: 200, position: [0, 9, 18] }}
      >
        {/* Sky / atmosphere */}
        <color attach="background" args={['#cfd6df']} />
        <fog attach="fog" args={['#cfd6df', 35, 75]} />

        {/* Lighting */}
        <ambientLight intensity={0.55} />
        <hemisphereLight args={['#ffffff', '#9aa6b2', 0.5]} />
        <directionalLight
          position={[12, 22, 8]}
          intensity={1.15}
          castShadow
          shadow-mapSize={[2048, 2048]}
          shadow-camera-near={1}
          shadow-camera-far={80}
          shadow-camera-left={-30}
          shadow-camera-right={30}
          shadow-camera-top={30}
          shadow-camera-bottom={-30}
          shadow-bias={-0.0004}
        />

        <Suspense fallback={null}>
          <CitySurroundings />
          <MainBuildingModel />
        </Suspense>

        {/* Owns camera behavior across both stages. */}
        <CameraDirector />
      </Canvas>

      {/* Loading progress (placeholders resolve near-instant; real GLBs stream). */}
      <LoadingOverlay />

      {/* Stage-specific HTML overlays */}
      {stage === 'CITY_ORBIT' && <FloorUnitSelector />}

      <AnimatePresence>
        {stage === 'ZOOM_TRANSITION' && <TransitionOverlay />}
      </AnimatePresence>
    </div>
  );
}
