'use client';

/**
 * About — building overview with an image and a short narrative + feature list.
 */
import { Check } from 'lucide-react';

const FEATURES = [
  'Floor-to-ceiling glass with panoramic city views',
  'Designer kitchens with integrated appliances',
  'Smart-home climate, lighting, and security',
  'Private balconies on every residence',
];

export function About() {
  return (
    <section id="about" className="bg-background py-20 sm:py-28">
      <div className="mx-auto grid max-w-7xl items-center gap-12 px-4 sm:px-6 lg:grid-cols-2 lg:gap-16 lg:px-8">
        {/* Image */}
        <div className="relative order-2 lg:order-1">
          <div className="aspect-[4/3] overflow-hidden rounded-3xl bg-gradient-to-br from-stone-200 to-stone-300 shadow-lg">
            <img
              src="/images/gallery-interior.png"
              alt="A bright, modern apartment living room at Aria Residences"
              className="h-full w-full object-cover"
              loading="lazy"
            />
          </div>
          <div className="absolute -bottom-6 -right-4 hidden rounded-2xl border border-border/60 bg-background/95 p-4 shadow-xl backdrop-blur sm:block">
            <div className="text-3xl font-semibold text-stone-900">4.9★</div>
            <div className="text-xs text-muted-foreground">Resident rating</div>
          </div>
        </div>

        {/* Copy */}
        <div className="order-1 lg:order-2">
          <span className="text-xs font-semibold uppercase tracking-[0.2em] text-amber-600">
            About the building
          </span>
          <h2 className="mt-3 text-3xl font-semibold tracking-tight text-stone-900 sm:text-4xl">
            Designed for the way you live now.
          </h2>
          <p className="mt-4 text-base leading-relaxed text-stone-600">
            Aria Residences pairs timeless architecture with thoughtful,
            human-scale interiors. Every floor plan was considered for light,
            flow, and flexibility — so each home feels distinct the moment you
            step inside. Explore any unit in full 3D before you ever book a
            tour.
          </p>
          <ul className="mt-8 space-y-3">
            {FEATURES.map((f) => (
              <li key={f} className="flex items-start gap-3">
                <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-amber-100 text-amber-700">
                  <Check className="h-3 w-3" />
                </span>
                <span className="text-sm text-stone-700">{f}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  );
}
