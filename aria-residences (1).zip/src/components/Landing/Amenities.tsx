'use client';

/**
 * Amenities — grid of building amenity cards.
 */
import {
  Waves,
  Dumbbell,
  Wifi,
  Trees,
  Car,
  ConciergeBell,
  Dog,
  Wine,
} from 'lucide-react';

const AMENITIES = [
  { icon: Waves, title: 'Rooftop pool', desc: 'Heated infinity pool with skyline views, open year-round.' },
  { icon: Dumbbell, title: 'Fitness studio', desc: 'Fully equipped gym with cardio, weights, and yoga room.' },
  { icon: ConciergeBell, title: '24/7 concierge', desc: 'Front-desk service, package handling, and guest support.' },
  { icon: Trees, title: 'Sky garden', desc: 'Landscaped terrace with loungers and barbecue pits.' },
  { icon: Car, title: 'EV parking', desc: 'Secure underground parking with EV charging on every level.' },
  { icon: Wifi, title: 'Smart building', desc: 'Gigabit fiber, keyless entry, and a resident app.' },
  { icon: Wine, title: 'Residents lounge', desc: 'Curated lounge and dining room for private events.' },
  { icon: Dog, title: 'Pet friendly', desc: 'Pet spa and dog run — your companions are family.' },
];

export function Amenities() {
  return (
    <section id="amenities" className="bg-stone-50 py-20 sm:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <span className="text-xs font-semibold uppercase tracking-[0.2em] text-amber-600">
            Amenities
          </span>
          <h2 className="mt-3 text-3xl font-semibold tracking-tight text-stone-900 sm:text-4xl">
            Everything you need, a few floors away.
          </h2>
          <p className="mt-4 text-base text-stone-600">
            Hotel-grade amenities designed for daily life — not just for show.
          </p>
        </div>

        <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {AMENITIES.map(({ icon: Icon, title, desc }) => (
            <div
              key={title}
              className="group rounded-2xl border border-stone-200 bg-background p-6 shadow-sm transition hover:-translate-y-1 hover:shadow-md"
            >
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-amber-100 text-amber-700 transition group-hover:bg-amber-600 group-hover:text-white">
                <Icon className="h-5 w-5" />
              </div>
              <h3 className="mt-4 text-base font-semibold text-stone-900">
                {title}
              </h3>
              <p className="mt-1.5 text-sm leading-relaxed text-stone-600">
                {desc}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
