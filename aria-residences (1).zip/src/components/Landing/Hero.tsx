'use client';

/**
 * Hero — marketing hero with headline, subhead, CTAs, and a small embedded 3D
 * building preview (dynamically imported, ssr:false to avoid SSR three.js).
 */
import dynamic from 'next/dynamic';
import { ArrowRight, Play } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAppStore } from '@/state/useAppStore';
import { BUILDING_NAME } from '@/config/apartments';

const HeroPreview = dynamic(() => import('./HeroPreview'), {
  ssr: false,
  loading: () => (
    <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-stone-100 to-amber-50">
      <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" />
    </div>
  ),
});

export function Hero() {
  const setStage = useAppStore((s) => s.setStage);

  return (
    <section
      id="home"
      className="relative overflow-hidden bg-gradient-to-b from-stone-100 via-stone-50 to-background pt-16"
    >
      {/* Decorative warm glow */}
      <div
        aria-hidden
        className="pointer-events-none absolute -right-32 top-0 h-[480px] w-[480px] rounded-full bg-amber-200/40 blur-3xl"
      />
      <div
        aria-hidden
        className="pointer-events-none absolute -left-32 top-40 h-[360px] w-[360px] rounded-full bg-rose-200/30 blur-3xl"
      />

      <div className="relative mx-auto grid max-w-7xl items-center gap-10 px-4 pb-20 pt-12 sm:px-6 lg:grid-cols-2 lg:gap-8 lg:px-8 lg:pb-32 lg:pt-20">
        {/* Copy */}
        <div className="max-w-xl">
          <span className="inline-flex items-center gap-2 rounded-full border border-amber-300/60 bg-amber-100/60 px-3 py-1 text-xs font-medium text-amber-800">
            <span className="h-1.5 w-1.5 rounded-full bg-amber-500" />
            Now leasing · Move-in ready
          </span>
          <h1 className="mt-5 text-4xl font-semibold leading-[1.05] tracking-tight text-stone-900 sm:text-5xl lg:text-6xl">
            Welcome home to{' '}
            <span className="bg-gradient-to-r from-amber-600 to-rose-500 bg-clip-text text-transparent">
              {BUILDING_NAME}
            </span>
          </h1>
          <p className="mt-5 text-base leading-relaxed text-stone-600 sm:text-lg">
            Twenty floors of light-filled, design-forward residences in the
            heart of the city. Pick your floor, choose your unit, and step
            inside for a first-person walkthrough — right from your browser.
          </p>
          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <Button size="lg" onClick={() => setStage('CITY_ORBIT')} className="group">
              Choose Apartment
              <ArrowRight className="ml-2 h-4 w-4 transition group-hover:translate-x-0.5" />
            </Button>
            <Button size="lg" variant="outline" asChild>
              <a href="#gallery">
                <Play className="mr-2 h-4 w-4" />
                View Gallery
              </a>
            </Button>
          </div>

          {/* Stats */}
          <dl className="mt-10 grid grid-cols-3 gap-4 border-t border-stone-200 pt-6">
            {[
              { k: '20', v: 'Floors' },
              { k: '80', v: 'Residences' },
              { k: '24/7', v: 'Concierge' },
            ].map((s) => (
              <div key={s.v}>
                <dt className="text-2xl font-semibold text-stone-900">{s.k}</dt>
                <dd className="text-xs uppercase tracking-wider text-stone-500">
                  {s.v}
                </dd>
              </div>
            ))}
          </dl>
        </div>

        {/* 3D preview */}
        <div className="relative">
          <div className="relative aspect-square w-full overflow-hidden rounded-3xl border border-stone-200/80 bg-gradient-to-br from-stone-100 to-stone-200 shadow-xl sm:aspect-[4/3] lg:aspect-square">
            <HeroPreview />
            <div className="pointer-events-none absolute bottom-3 left-3 rounded-full bg-background/80 px-3 py-1 text-[11px] font-medium text-foreground/70 backdrop-blur-md">
              Live 3D preview
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
