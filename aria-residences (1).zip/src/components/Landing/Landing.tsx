'use client';

/**
 * Landing — composes the marketing page (navbar + sections + sticky footer).
 *
 * Layout uses min-h-screen + flex flex-col with the footer pushed via mt-auto
 * so it always sticks to the bottom on short viewports and is pushed down
 * naturally on long ones (per the project's sticky-footer rule).
 */
import { useEffect } from 'react';
import { Navbar } from './Navbar';
import { Hero } from './Hero';
import { About } from './About';
import { Amenities } from './Amenities';
import { Location } from './Location';
import { Gallery } from './Gallery';
import { Contact } from './Contact';
import { Footer } from './Footer';

export default function Landing() {
  // Enable smooth scrolling for the in-page nav anchors.
  useEffect(() => {
    const prev = document.documentElement.style.scrollBehavior;
    document.documentElement.style.scrollBehavior = 'smooth';
    return () => {
      document.documentElement.style.scrollBehavior = prev;
    };
  }, []);

  return (
    <div className="flex min-h-screen flex-col bg-background">
      <Navbar />
      <main className="flex-1">
        <Hero />
        <About />
        <Amenities />
        <Location />
        <Gallery />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}
