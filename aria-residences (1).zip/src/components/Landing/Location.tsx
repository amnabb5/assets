'use client';

/**
 * Location — a stylized map panel with the address and nearby points.
 */
import { MapPin, Navigation, Clock } from 'lucide-react';

const NEARBY = [
  { name: 'Central Park', time: '5 min walk' },
  { name: 'Metro Station', time: '3 min walk' },
  { name: 'Riverside Promenade', time: '8 min walk' },
  { name: 'Dining & retail district', time: '4 min walk' },
];

export function Location() {
  return (
    <section id="location" className="bg-background py-20 sm:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid gap-12 lg:grid-cols-2 lg:gap-16">
          {/* Map */}
          <div className="relative overflow-hidden rounded-3xl border border-stone-200 bg-stone-100 shadow-sm">
            <div className="aspect-[4/3] w-full">
              <img
                src="/images/location-map.png"
                alt="Neighborhood map around Aria Residences"
                className="h-full w-full object-cover"
                loading="lazy"
              />
            </div>
            {/* Pin */}
            <div className="pointer-events-none absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-full">
              <span className="relative flex h-5 w-5">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-rose-400 opacity-60" />
                <span className="relative inline-flex h-5 w-5 items-center justify-center rounded-full bg-rose-500 text-white shadow-lg">
                  <MapPin className="h-3 w-3" />
                </span>
              </span>
            </div>
          </div>

          {/* Copy */}
          <div className="flex flex-col justify-center">
            <span className="text-xs font-semibold uppercase tracking-[0.2em] text-amber-600">
              Location
            </span>
            <h2 className="mt-3 text-3xl font-semibold tracking-tight text-stone-900 sm:text-4xl">
              Where the city meets the park.
            </h2>
            <p className="mt-4 text-base leading-relaxed text-stone-600">
              Tucked between the riverfront and the retail district, Aria puts
              the best of the city within a short walk — without the noise.
            </p>

            <div className="mt-6 flex items-start gap-3 rounded-2xl border border-stone-200 bg-stone-50 p-4">
              <Navigation className="mt-0.5 h-5 w-5 shrink-0 text-amber-600" />
              <div>
                <div className="text-sm font-semibold text-stone-900">
                  88 Aria Boulevard, Riverside District
                </div>
                <div className="text-sm text-stone-600">
                  Open daily · 9:00 AM – 7:00 PM
                </div>
              </div>
            </div>

            <ul className="mt-6 grid gap-3 sm:grid-cols-2">
              {NEARBY.map((n) => (
                <li
                  key={n.name}
                  className="flex items-center justify-between rounded-xl border border-stone-200 bg-background px-4 py-3"
                >
                  <span className="text-sm font-medium text-stone-800">
                    {n.name}
                  </span>
                  <span className="inline-flex items-center gap-1 text-xs text-stone-500">
                    <Clock className="h-3 w-3" />
                    {n.time}
                  </span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}
