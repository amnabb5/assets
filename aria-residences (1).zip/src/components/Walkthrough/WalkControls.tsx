'use client';
/* eslint-disable react-hooks/immutability -- R3F's camera/gl are mutated
   imperatively by design (the intended API for useThree values). The
   react-hooks/immutability rule flags this as a false positive. */

/**
 * WalkControls — first-person movement + look, runs inside the R3F Canvas.
 *
 * Input sources (all write into the shared `inputRef`):
 *   - Desktop: WASD / Arrow keys for movement, mouse-drag on the canvas to look.
 *   - Mobile: the <MobileControls /> HTML overlay writes the same refs
 *     (left joystick → move, right drag → look).
 *
 * On mount it snaps the camera to the apartment's spawn point. Each frame it
 * applies movement (in the XZ plane, so no flying) and consumes the look delta,
 * then clamps the position to the room bounds (v1 free-fly within the
 * placeholder room footprint; see BOUNDS below).
 *
 * NOTE: collision is a simple AABB clamp, not real mesh collision — acceptable
 * for v1 per the brief. For real models with different footprints, edit BOUNDS.
 */
import { useEffect, useRef } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import * as THREE from 'three';
import type { SpawnConfig } from '@/config/apartments';

export interface WalkInput {
  /** x = strafe (-1..1), y = forward (-1..1). Mobile joystick + keyboard. */
  move: { x: number; y: number };
  /** Accumulated pixel deltas to consume each frame. Desktop drag + mobile drag. */
  look: { x: number; y: number };
}

interface WalkControlsProps {
  inputRef: React.MutableRefObject<WalkInput>;
  spawn: SpawnConfig;
}

const SPEED = 2.4; // world units / second
const LOOK_SENSITIVITY = 0.0024; // radians per pixel
const PITCH_LIMIT = 1.4; // radians (~80°)

// Soft AABB bounds inside the placeholder room (interior 6×6, margin 0.4).
// Tweak when real models land if the footprint differs.
const BOUNDS = {
  minX: -2.6,
  maxX: 2.6,
  minZ: -2.6,
  maxZ: 2.6,
};

export function WalkControls({ inputRef, spawn }: WalkControlsProps) {
  const { camera, gl } = useThree();
  const keys = useRef<Set<string>>(new Set());
  const dragging = useRef(false);
  const lastPointer = useRef({ x: 0, y: 0 });
  const forwardVec = useRef(new THREE.Vector3());
  const rightVec = useRef(new THREE.Vector3());
  const upVec = useRef(new THREE.Vector3(0, 1, 0));
  const moveVec = useRef(new THREE.Vector3());

  // Spawn the camera at the entry point.
  useEffect(() => {
    const cam = camera as THREE.PerspectiveCamera;
    cam.rotation.order = 'YXZ'; // yaw (Y) then pitch (X) — avoids roll
    cam.position.set(...spawn.position);
    cam.rotation.set(...spawn.rotation);
    cam.fov = 62;
    cam.near = 0.05;
    cam.far = 100;
    cam.updateProjectionMatrix();
  }, [camera, spawn]);

  // Keyboard listeners (desktop).
  useEffect(() => {
    const isMoveKey = (k: string) =>
      [
        'w', 'a', 's', 'd',
        'arrowup', 'arrowdown', 'arrowleft', 'arrowright',
      ].includes(k.toLowerCase());

    const onDown = (e: KeyboardEvent) => {
      if (isMoveKey(e.key)) {
        keys.current.add(e.key.toLowerCase());
        // Prevent page scroll on arrow keys.
        if (e.key.startsWith('Arrow')) e.preventDefault();
      }
    };
    const onUp = (e: KeyboardEvent) => {
      keys.current.delete(e.key.toLowerCase());
    };
    const onBlur = () => keys.current.clear();

    window.addEventListener('keydown', onDown);
    window.addEventListener('keyup', onUp);
    window.addEventListener('blur', onBlur);
    return () => {
      window.removeEventListener('keydown', onDown);
      window.removeEventListener('keyup', onUp);
      window.removeEventListener('blur', onBlur);
    };
  }, []);

  // Mouse-drag look (desktop only — touch is handled by MobileControls overlay).
  useEffect(() => {
    const dom = gl.domElement;

    const onPointerDown = (e: PointerEvent) => {
      if (e.pointerType !== 'mouse' || e.button !== 0) return;
      dragging.current = true;
      lastPointer.current = { x: e.clientX, y: e.clientY };
      dom.style.cursor = 'grabbing';
    };
    const onPointerMove = (e: PointerEvent) => {
      if (e.pointerType !== 'mouse' || !dragging.current) return;
      const dx = e.clientX - lastPointer.current.x;
      const dy = e.clientY - lastPointer.current.y;
      lastPointer.current = { x: e.clientX, y: e.clientY };
      inputRef.current.look.x += dx;
      inputRef.current.look.y += dy;
    };
    const onPointerUp = (e: PointerEvent) => {
      if (e.pointerType !== 'mouse') return;
      dragging.current = false;
      dom.style.cursor = 'grab';
    };

    dom.style.cursor = 'grab';
    dom.addEventListener('pointerdown', onPointerDown);
    window.addEventListener('pointermove', onPointerMove);
    window.addEventListener('pointerup', onPointerUp);
    return () => {
      dom.removeEventListener('pointerdown', onPointerDown);
      window.removeEventListener('pointermove', onPointerMove);
      window.removeEventListener('pointerup', onPointerUp);
    };
  }, [gl, inputRef]);

  useFrame((_, delta) => {
    const cam = camera as THREE.PerspectiveCamera;
    const dt = Math.min(delta, 0.05); // clamp big frame gaps

    // --- Look: consume accumulated pixel deltas. ---
    const look = inputRef.current.look;
    if (look.x !== 0 || look.y !== 0) {
      cam.rotation.y -= look.x * LOOK_SENSITIVITY;
      cam.rotation.x -= look.y * LOOK_SENSITIVITY;
      // Clamp pitch.
      cam.rotation.x = Math.max(
        -PITCH_LIMIT,
        Math.min(PITCH_LIMIT, cam.rotation.x)
      );
      look.x = 0;
      look.y = 0;
    }

    // --- Move: keyboard takes priority; otherwise use mobile move vector. ---
    let mx = 0;
    let my = 0;
    const k = keys.current;
    if (k.has('w') || k.has('arrowup')) my += 1;
    if (k.has('s') || k.has('arrowdown')) my -= 1;
    if (k.has('d') || k.has('arrowright')) mx += 1;
    if (k.has('a') || k.has('arrowleft')) mx -= 1;

    if (mx === 0 && my === 0) {
      // Fall back to mobile joystick input.
      mx = inputRef.current.move.x;
      my = inputRef.current.move.y;
    }

    if (mx !== 0 || my !== 0) {
      // Forward in the XZ plane (ignore pitch so we don't fly).
      cam.getWorldDirection(forwardVec.current);
      forwardVec.current.y = 0;
      forwardVec.current.normalize();
      rightVec.current.crossVectors(forwardVec.current, upVec.current).normalize();

      moveVec.current
        .set(0, 0, 0)
        .addScaledVector(forwardVec.current, my)
        .addScaledVector(rightVec.current, mx);

      if (moveVec.current.lengthSq() > 1) moveVec.current.normalize();

      cam.position.addScaledVector(moveVec.current, SPEED * dt);
    }

    // Keep eye height fixed (no vertical drift) and clamp to room bounds.
    cam.position.y = spawn.position[1];
    cam.position.x = Math.max(BOUNDS.minX, Math.min(BOUNDS.maxX, cam.position.x));
    cam.position.z = Math.max(BOUNDS.minZ, Math.min(BOUNDS.maxZ, cam.position.z));
  });

  return null;
}
