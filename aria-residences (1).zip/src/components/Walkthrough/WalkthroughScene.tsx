'use client';

/**
 * WalkthroughScene — first-person interior walkthrough.
 *
 * Loads the selected apartment model via <ApartmentModel /> (placeholder room
 * today, real GLB later — same interface). Spawns the camera at the apartment's
 * entry point and hands control to <WalkControls /> (desktop) or
 * <MobileControls /> (touch).
 *
 * Overlays: Exit button, crosshair reticle, desktop control hint (auto-hide),
 * a "Coming soon" banner when an apartment has no model mapped, and the shared
 * loading overlay.
 */
import { useEffect, useMemo, useRef, useState } from 'react';
import { Canvas } from '@react-three/fiber';
import * as THREE from 'three';
import { useAppStore } from '@/state/useAppStore';
import {
  getApartmentKey,
  getApartment,
  getSpawnConfig,
  type SpawnConfig,
} from '@/config/apartments';
import { ApartmentModel } from '@/components/three/ApartmentModel';
import { WalkControls, type WalkInput } from './WalkControls';
import { MobileControls } from './MobileControls';
import { LoadingOverlay } from '@/components/three/LoadingOverlay';
import { ArrowLeft, Move, MousePointer2, Hand } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function WalkthroughScene() {
  const selectedFloor = useAppStore((s) => s.selectedFloor);
  const selectedUnit = useAppStore((s) => s.selectedUnit);
  const storeSpawn = useAppStore((s) => s.spawn);
  const backToOrbit = useAppStore((s) => s.backToOrbit);

  const inputRef = useRef<WalkInput>({ move: { x: 0, y: 0 }, look: { x: 0, y: 0 } });
  const [isTouch, setIsTouch] = useState(false);
  const [comingSoon, setComingSoon] = useState(false);
  const [showHint, setShowHint] = useState(true);

  const apartmentKey = useMemo(
    () =>
      selectedFloor != null && selectedUnit != null
        ? getApartmentKey(selectedFloor, selectedUnit)
        : '',
    [selectedFloor, selectedUnit]
  );

  const spawn: SpawnConfig = useMemo(
    () =>
      storeSpawn ??
      (selectedFloor != null && selectedUnit != null
        ? getSpawnConfig(selectedFloor, selectedUnit)
        : { position: [0, 1.5, 2.2], rotation: [0, 0, 0] }),
    [storeSpawn, selectedFloor, selectedUnit]
  );

  // Detect touch device for control scheme selection.
  // Robust across real phones (pointer: coarse), pure-touch devices, and
  // emulated/hybrid environments. Excludes touch laptops with a fine pointer
  // at wide widths so they keep desktop drag-look.
  useEffect(() => {
    const compute = () => {
      const coarse = window.matchMedia('(pointer: coarse)').matches;
      const touchCapable =
        'ontouchstart' in window || navigator.maxTouchPoints > 0;
      const narrow = window.innerWidth <= 820;
      const mobileUA = /Mobi|Android|iPhone|iPad/i.test(navigator.userAgent);
      setIsTouch(coarse || (touchCapable && narrow) || (mobileUA && narrow));
    };
    compute();
    const onResize = () => compute();
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, []);

  // Auto-hide the desktop control hint after a few seconds.
  useEffect(() => {
    if (isTouch) return;
    const t = setTimeout(() => setShowHint(false), 6000);
    return () => clearTimeout(t);
  }, [isTouch]);

  const spec = getApartment(selectedFloor ?? 0, selectedUnit ?? '');

  return (
    <div className="fixed inset-0 z-40 bg-[#1a1a1f]">
      <Canvas
        shadows
        dpr={[1, 2]}
        gl={{ antialias: true, toneMapping: THREE.ACESFilmicToneMapping }}
        camera={{ fov: 62, near: 0.05, far: 100, position: spawn.position }}
      >
        {/* Soft interior background (seen through the doorway). */}
        <color attach="background" args={['#b9c6d2']} />

        {/* Lighting — works for both placeholder room and real GLBs. */}
        <ambientLight intensity={0.75} />
        <hemisphereLight args={['#ffffff', '#b8a888', 0.5]} />
        {/* Daylight from the window side. */}
        <directionalLight
          position={[-4, 4, -6]}
          intensity={0.6}
          color="#cfe8f5"
          castShadow
          shadow-mapSize={[1024, 1024]}
        />
        {/* Warm ceiling fill. */}
        <pointLight
          position={[0, 2.2, 0]}
          intensity={14}
          distance={10}
          decay={2}
          color="#fff2dc"
        />

        <ApartmentModel apartmentKey={apartmentKey} onComingSoon={setComingSoon} />

        <WalkControls inputRef={inputRef} spawn={spawn} />
      </Canvas>

      {/* Loading progress (real GLBs stream; placeholder is near-instant). */}
      <LoadingOverlay label="Loading apartment" />

      {/* ---- HTML overlays ---- */}

      {/* Top bar: exit + apartment label */}
      <div className="pointer-events-none absolute inset-x-0 top-0 z-30 flex items-center justify-between p-3 sm:p-4">
        <Button
          variant="secondary"
          size="sm"
          className="pointer-events-auto gap-1.5 bg-background/80 backdrop-blur-md"
          onClick={backToOrbit}
        >
          <ArrowLeft className="h-4 w-4" />
          Exit Walkthrough
        </Button>
        {spec && (
          <div className="pointer-events-none rounded-full bg-background/70 px-3 py-1.5 text-xs font-medium text-foreground/80 backdrop-blur-md sm:text-sm">
            {apartmentKey} · {spec.beds} bed · {spec.facing}
          </div>
        )}
      </div>

      {/* Crosshair */}
      <div className="pointer-events-none absolute inset-0 z-20 flex items-center justify-center">
        <div className="h-1.5 w-1.5 rounded-full bg-white/70 shadow ring-1 ring-black/20" />
      </div>

      {/* Desktop control hint */}
      {!isTouch && showHint && (
        <div className="pointer-events-none absolute bottom-6 left-1/2 z-30 -translate-x-1/2 animate-pulse">
          <div className="flex items-center gap-4 rounded-full bg-background/80 px-4 py-2 text-xs text-foreground/80 backdrop-blur-md">
            <span className="inline-flex items-center gap-1.5">
              <Move className="h-3.5 w-3.5" />
              WASD / Arrows to move
            </span>
            <span className="h-3 w-px bg-border" />
            <span className="inline-flex items-center gap-1.5">
              <MousePointer2 className="h-3.5 w-3.5" />
              Drag to look
            </span>
          </div>
        </div>
      )}

      {/* Mobile hint (brief) */}
      {isTouch && showHint && (
        <div className="pointer-events-none absolute bottom-44 left-1/2 z-30 -translate-x-1/2">
          <div className="flex items-center gap-2 rounded-full bg-background/80 px-4 py-2 text-xs text-foreground/80 backdrop-blur-md">
            <Hand className="h-3.5 w-3.5" />
            Joystick to move · drag right to look
          </div>
        </div>
      )}

      {/* Mobile touch controls */}
      {isTouch && <MobileControls inputRef={inputRef} />}

      {/* Coming soon banner */}
      {comingSoon && (
        <div className="pointer-events-none absolute inset-0 z-30 flex items-center justify-center p-6">
          <div className="max-w-md rounded-2xl border border-border/60 bg-background/90 p-6 text-center shadow-2xl backdrop-blur-xl">
            <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-amber-500/15 text-amber-600">
              <Hand className="h-6 w-6" />
            </div>
            <h3 className="text-lg font-semibold">Coming soon</h3>
            <p className="mt-1 text-sm text-muted-foreground">
              The 3D model for apartment{' '}
              <span className="font-medium text-foreground">{apartmentKey}</span>{' '}
              isn&rsquo;t available yet. You&rsquo;re exploring a preview space.
            </p>
            <Button
              variant="outline"
              size="sm"
              className="pointer-events-auto mt-4"
              onClick={backToOrbit}
            >
              Choose another apartment
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
