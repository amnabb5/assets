'use client';

/**
 * ApartmentModel — the single swap point for the apartment-interior model.
 *
 * Resolution logic for a given apartment key (e.g. "3-A"):
 *   1. USE_PLACEHOLDER_MODELS === true
 *        → render the procedural <PlaceholderRoom /> (works for every apartment)
 *   2. USE_PLACEHOLDER_MODELS === false AND a real GLB is mapped
 *        → render <GLTFModel path={url} />
 *   3. USE_PLACEHOLDER_MODELS === false AND no GLB is mapped yet
 *        → render a <ComingSoon /> marker (the parent shows an HTML overlay)
 *
 * This guarantees the app NEVER crashes on an unmapped apartment — it either
 * shows the placeholder room or a friendly "Coming soon" notice.
 */
import { Suspense } from 'react';
import { PlaceholderRoom } from '@/components/Walkthrough/PlaceholderRoom';
import { GLTFModel } from './GLTFModel';
import {
  USE_PLACEHOLDER_MODELS,
  resolveApartmentModelUrl,
} from '@/config/assets';

interface ApartmentModelProps {
  apartmentKey: string;
  /** Called with true when this apartment has no model available (coming soon). */
  onComingSoon?: (comingSoon: boolean) => void;
}

export function ApartmentModel({ apartmentKey, onComingSoon }: ApartmentModelProps) {
  // Path 1: placeholders — always render the procedural room.
  if (USE_PLACEHOLDER_MODELS) {
    onComingSoon?.(false);
    return (
      <Suspense fallback={null}>
        <PlaceholderRoom apartmentKey={apartmentKey} />
      </Suspense>
    );
  }

  // Path 2/3: real models.
  const url = resolveApartmentModelUrl(apartmentKey);

  if (!url) {
    // Path 3: no real model mapped yet.
    onComingSoon?.(true);
    return <ComingSoonMarker />;
  }

  onComingSoon?.(false);
  return (
    <Suspense fallback={null}>
      <GLTFModel path={url} />
    </Suspense>
  );
}

/**
 * Invisible marker placed in the scene so the walkthrough still has a
 * navigable (empty) space. The HTML "Coming soon" overlay is rendered by
 * the parent WalkthroughScene based on the onComingSoon callback.
 */
function ComingSoonMarker() {
  return (
    <group>
      {/* Minimal floor so the player isn't floating in void. */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0, 0]} receiveShadow>
        <planeGeometry args={[6, 6]} />
        <meshStandardMaterial color="#e7e5e4" />
      </mesh>
    </group>
  );
}
