'use client';

/**
 * GLTFModel — loads a real .glb scene via drei's useGLTF.
 *
 * This is the REAL-model code path. It is only reached when
 * USE_PLACEHOLDER_MODELS === false (see src/config/assets.ts).
 *
 * Uses DRACOLoader (via drei's useGLTF second arg) so Draco-compressed
 * GLBs load efficiently. drei's useGLTF also reports to THREE's
 * DefaultLoadingManager, so the shared <LoadingOverlay /> (which uses
 * drei's useProgress) works for free.
 */
import { useGLTF } from '@react-three/drei';
import { DRACO_DECODER_PATH } from '@/config/assets';
import { useEffect } from 'react';
import * as THREE from 'three';

interface GLTFModelProps {
  path: string;
  /** Optional scale to fit your model into the scene's unit system. */
  scale?: number | [number, number, number];
  /** Optional position offset (use if your GLB's origin isn't centered). */
  position?: [number, number, number];
  /** Optional rotation (radians). */
  rotation?: [number, number, number];
}

export function GLTFModel({
  path,
  scale = 1,
  position = [0, 0, 0],
  rotation = [0, 0, 0],
}: GLTFModelProps) {
  // useGLTF(path, useDraco) — passing the decoder path enables Draco decoding.
  const { scene } = useGLTF(path, DRACO_DECODER_PATH);

  // Enable shadows on every mesh in the loaded scene (nice for the walkthrough).
  useEffect(() => {
    scene.traverse((obj) => {
      if ((obj as THREE.Mesh).isMesh) {
        obj.castShadow = true;
        obj.receiveShadow = true;
      }
    });
  }, [scene]);

  return (
    <primitive object={scene} position={position} rotation={rotation} scale={scale} />
  );
}
