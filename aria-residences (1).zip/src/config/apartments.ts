/**
 * ============================================================================
 *  APARTMENTS CONFIG  —  floors, units, specs, and walkthrough spawn points
 * ============================================================================
 *
 *  This is the single source of truth for the building's floor/unit layout and
 *  the apartment specs shown in the selector UI. Add/remove floors or units
 *  here and the rest of the app follows automatically.
 *
 *  IMPORTANT — camera target coordinates for the ZOOM_TRANSITION live in
 *  `BUILDING_CONFIG` below. When you swap in a real main-building GLB whose
 *  scale/origin differs from the placeholder, tweak these numbers (and
 *  `floorWorldY`) so the camera flies to the correct floor height and the
 *  facade position of the real model.
 * ============================================================================
 */

export type Facing = 'North' | 'South' | 'East' | 'West';

export interface ApartmentSpec {
  /** Unit letter, e.g. "A" */
  unit: string;
  beds: number;
  baths: number;
  sqft: number;
  facing: Facing;
  /** Monthly rent / price display string */
  price: string;
}

export interface FloorConfig {
  floor: number;
  /** Display name, e.g. "Floor 3" or "Penthouse" */
  name: string;
  units: ApartmentSpec[];
}

/** Display name of the residence. */
export const BUILDING_NAME = 'Aria Residences';

/**
 * Building geometry used by BOTH the placeholder scene AND the zoom-transition
 * camera math. When real models arrive, keep these in sync with the real
 * model's actual proportions so the camera flies to the right spot.
 */
export const BUILDING_CONFIG = {
  /** World-space center of the building's main mass. */
  center: [0, 10, 0] as [number, number, number],
  /** Total height of the building mass in world units. */
  totalHeight: 20,
  /** Number of above-ground floors. */
  floors: 20,
  /** Height of one floor in world units (totalHeight / floors). */
  floorHeight: 1,
  /** Building footprint [width (x), depth (z)] in world units. */
  footprint: [4, 4] as [number, number],
  /**
   * The facade the camera flies toward during ZOOM_TRANSITION.
   * The camera ends just outside this face (the +Z face of the building,
   * which sits at z = footprint[1]/2 = 2) at the selected floor's height.
   * Swap to a different face/position to match your real model's entrance.
   *
   * TWEAK THIS when real models land if their scale/origin differs.
   */
  facadeTarget: [0, 0, 2] as [number, number, number],
} as const;

/**
 * Convert a floor number to its world-space Y (center of that floor's slab).
 * Floors are numbered 1..N from the ground up.
 */
export function floorWorldY(floor: number): number {
  // Floor 1 center sits at floorHeight/2; floor N at (N-0.5)*floorHeight.
  return (floor - 0.5) * BUILDING_CONFIG.floorHeight;
}

/**
 * Build a stable apartment key from floor + unit, e.g. (3, "A") → "3-A".
 * This is the key used to look up real GLB paths in `apartmentModelMap`.
 */
export function getApartmentKey(floor: number, unit: string): string {
  return `${floor}-${unit}`;
}

/**
 * Spawn point + initial heading for the first-person walkthrough.
 * The placeholder room is built with its doorway on the -Z wall, so the
 * default spawn sits just inside the door facing +X (into the room).
 *
 * For real apartment models, override per-apartment by editing the entry in
 * the `apartments` map below — add `spawn` / `spawnRotation` there once you
 * know each real model's origin and orientation.
 */
export interface SpawnConfig {
  position: [number, number, number];
  /** Euler rotation in radians [x, y, z]. y = yaw. */
  rotation: [number, number, number];
}

const DEFAULT_SPAWN: SpawnConfig = {
  position: [0, 1.5, 2.2],
  rotation: [0, 0, 0], // face -Z (into the room from the doorway on the +Z wall)
};

// NOTE on spawn orientation: the placeholder room's doorway is on the +Z wall
// (front wall at z = +3). The player spawns just inside the door at z = 2.2 and
// faces -Z (rotation y = 0) so they look INTO the room on entry. This matches
// the zoom transition, which flies the camera toward the +Z facade.
// y = 1.5 is a realistic eye height for the 2.4-tall placeholder room.
const PLACEHOLDER_SPAWN: SpawnConfig = {
  position: [0, 1.5, 2.2],
  rotation: [0, 0, 0],
};

/**
 * Master floor/unit configuration. Edit freely to add floors/units.
 * Floors 1–20, each with units A–D. Specs vary a little per unit type so the
 * selector UI has something real to show.
 */
const UNIT_TYPES: Record<string, Omit<ApartmentSpec, 'unit'>> = {
  A: { beds: 1, baths: 1, sqft: 640, facing: 'North', price: '$2,400/mo' },
  B: { beds: 2, baths: 2, sqft: 980, facing: 'East', price: '$3,650/mo' },
  C: { beds: 2, baths: 2, sqft: 1040, facing: 'South', price: '$3,900/mo' },
  D: { beds: 3, baths: 2, sqft: 1380, facing: 'West', price: '$5,200/mo' },
};

const UNIT_LETTERS = ['A', 'B', 'C', 'D'] as const;

export const floors: FloorConfig[] = Array.from(
  { length: BUILDING_CONFIG.floors },
  (_, i) => {
    const floor = i + 1;
    const isPenthouse = floor >= 18;
    return {
      floor,
      name: isPenthouse
        ? floor === 20
          ? 'Sky Penthouse'
          : `Penthouse ${floor}`
        : `Floor ${floor}`,
      units: UNIT_LETTERS.map((unit) => ({
        unit,
        ...UNIT_TYPES[unit],
        // Penthouses get a price bump for flavor.
        price: isPenthouse
          ? `$${Math.round(
              parseInt(UNIT_TYPES[unit].price.replace(/\D/g, ''), 10) * 1.35
            ).toLocaleString()}/mo`
          : UNIT_TYPES[unit].price,
      })),
    };
  }
);

/**
 * Look up a single apartment by floor + unit.
 */
export function getApartment(floor: number, unit: string): ApartmentSpec | null {
  const f = floors.find((x) => x.floor === floor);
  if (!f) return null;
  return f.units.find((u) => u.unit === unit) ?? null;
}

/**
 * Spawn config for a given apartment. Today all apartments reuse the
 * placeholder spawn; override here per-apartment when real models land.
 */
export function getSpawnConfig(floor: number, unit: string): SpawnConfig {
  // When placeholders are active the room geometry is identical for every
  // apartment, so the same spawn works everywhere.
  void floor;
  void unit;
  return PLACEHOLDER_SPAWN;
}

// Re-export for convenience in components that only need the default.
export { DEFAULT_SPAWN };
