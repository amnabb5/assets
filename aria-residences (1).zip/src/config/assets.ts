/**
 * ============================================================================
 *  ASSET CONFIG  —  THE ONLY FILE YOU TOUCH WHEN SWAPPING IN REAL MODELS
 * ============================================================================
 *
 *  This is the central swap-in point referenced by the brief.
 *
 *  TODAY: the app builds procedural placeholders (Three.js primitives) for the
 *  city, main building, and apartment interior. Everything works end-to-end.
 *
 *  WHEN YOUR REAL GLB FILES ARE READY:
 *    1. Drop `main-building.glb` into  /public/models/
 *    2. Drop apartment GLBs into       /public/models/apartments/
 *    3. Register each apartment's GLB path in `apartmentModelMap` below
 *       (the key is the apartment key returned by `getApartmentKey(floor, unit)`,
 *        e.g. "3-A").
 *    4. Flip `USE_PLACEHOLDER_MODELS` to `false`.
 *
 *  That's it — no other code changes are required. The same `useModel` hook,
 *  the same `useProgress` loaders, and the same camera/zoom logic all keep
 *  working because placeholders live behind the exact same loading interface.
 *
 *  If an apartment has NO entry in `apartmentModelMap` AND placeholders are
 *  off, the walkthrough shows a friendly "Coming soon" panel instead of crashing.
 * ============================================================================
 */

/**
 * Master switch.
 *  true  → render procedural placeholders (default, today)
 *  false → load real .glb files via useGLTF (after you drop them in /public/models)
 */
export const USE_PLACEHOLDER_MODELS = true;

/**
 * Path to the real main-building model (used when USE_PLACEHOLDER_MODELS = false).
 */
export const MAIN_BUILDING_MODEL = '/models/main-building.glb';

/**
 * Map of apartment key → real GLB path.
 * Apartment keys follow the pattern `${floor}-${unit}`, e.g. "3-A", "12-D".
 * Leave empty for now; populate it as you add real apartment GLBs.
 *
 * Example (once real files exist):
 *   '3-A':  '/models/apartments/apartment-3.glb',
 *   '3-B':  '/models/apartments/apartment-3.glb',
 *   '12-D': '/models/apartments/penthouse-12.glb',
 */
export const apartmentModelMap: Record<string, string> = {
  // '3-A': '/models/apartments/apartment-3.glb',
};

/**
 * Optional Draco decoder path. drei's useGLTF supports Draco-compressed GLBs.
 * When you export GLBs with Draco mesh compression, point this at the decoder
 * (drei ships a copy, so this default usually just works). No-op for placeholders.
 */
export const DRACO_DECODER_PATH =
  'https://www.gstatic.com/draco/versioned/decoders/1.5.6/';

/**
 * Resolve the GLB URL for a given apartment key.
 * Returns `null` when no model is mapped yet (so the UI can show "Coming soon").
 */
export function resolveApartmentModelUrl(apartmentKey: string): string | null {
  return apartmentModelMap[apartmentKey] ?? null;
}
