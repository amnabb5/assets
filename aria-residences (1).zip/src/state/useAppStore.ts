/**
 * Global app store (Zustand).
 *
 * Drives the high-level state machine:
 *   LANDING → CITY_ORBIT → ZOOM_TRANSITION → WALKTHROUGH
 * and the current apartment selection.
 */
import { create } from 'zustand';
import {
  getApartmentKey,
  getSpawnConfig,
  type SpawnConfig,
} from '@/config/apartments';
import { resolveApartmentModelUrl } from '@/config/assets';

export type Stage = 'LANDING' | 'CITY_ORBIT' | 'ZOOM_TRANSITION' | 'WALKTHROUGH';

interface AppState {
  stage: Stage;
  selectedFloor: number | null;
  selectedUnit: string | null;
  /** Resolved GLB url (null = placeholder or "coming soon"). */
  apartmentModelUrl: string | null;
  /** Whether the selected apartment has a real model mapped. */
  hasRealModel: boolean;
  /** Resolved spawn for the walkthrough. */
  spawn: SpawnConfig | null;

  // actions
  setStage: (stage: Stage) => void;
  selectFloor: (floor: number | null) => void;
  selectUnit: (unit: string | null) => void;
  /** Resolve the apartment for the current selection. */
  confirmSelection: () => void;
  /** Reset selection + return to landing. */
  resetToLanding: () => void;
  /** Return to orbit from walkthrough/transition (keeps selection). */
  backToOrbit: () => void;
}

export const useAppStore = create<AppState>((set, get) => ({
  stage: 'LANDING',
  selectedFloor: null,
  selectedUnit: null,
  apartmentModelUrl: null,
  hasRealModel: false,
  spawn: null,

  setStage: (stage) => set({ stage }),

  selectFloor: (floor) =>
    set({ selectedFloor: floor, selectedUnit: null, apartmentModelUrl: null }),

  selectUnit: (unit) => {
    const { selectedFloor } = get();
    if (!selectedFloor || !unit) {
      set({ selectedUnit: unit, apartmentModelUrl: null, hasRealModel: false });
      return;
    }
    const key = getApartmentKey(selectedFloor, unit);
    const url = resolveApartmentModelUrl(key);
    set({
      selectedUnit: unit,
      // url is null under placeholders OR when no real model is mapped.
      apartmentModelUrl: url,
      hasRealModel: !!url,
    });
  },

  confirmSelection: () => {
    const { selectedFloor, selectedUnit } = get();
    if (!selectedFloor || !selectedUnit) return;
    const spawn = getSpawnConfig(selectedFloor, selectedUnit);
    set({ spawn, stage: 'ZOOM_TRANSITION' });
  },

  resetToLanding: () =>
    set({
      stage: 'LANDING',
      selectedFloor: null,
      selectedUnit: null,
      apartmentModelUrl: null,
      hasRealModel: false,
      spawn: null,
    }),

  backToOrbit: () => set({ stage: 'CITY_ORBIT' }),
}));
